require('../stylesheets/less/index.less');
